
# User Stories (mínimo 2)

## Épico: Compras - SwagLabs Shopping

### US-01 — Login do usuário
**Como** usuário autenticado por email  
**Quero** fazer login com minhas credenciais válidas  
**Para que** eu consiga acessar minha conta e funcionalidades personalizadas (carrinho, pedidos).

**Critérios de aceite**
- Dado que eu tenho uma conta válida, quando eu submeter email e senha corretos, então devo ser redirecionado para a página de produtos.
- Se credenciais inválidas, exibir mensagem de erro clara e não permitir acesso.
- Campo senha deve mascarar o conteúdo.
- Recuperação de senha com link funcional na tela de login.

### US-02 — Finalizar compra (Checkout)
**Como** comprador autenticado  
**Quero** adicionar produtos ao carrinho e finalizar a compra com dados de pagamento fictícios  
**Para que** eu consiga concluir pedidos com sucesso e receber confirmação.

**Critérios de aceite**
- Dado que itens estão no carrinho, quando eu fizer checkout com cartão válido (teste), então o pedido deve ser criado e mostrar número de pedido.
- Se o pagamento falhar, exibir erro e manter os itens no carrinho.
- O total deve refletir quantidade × preço e impostos simulados.
- Usuário deve poder aplicar cupom (opcional) e ver desconto aplicado.

## Observações
- As histórias seguem INVEST: independentes, negociáveis e testáveis.
