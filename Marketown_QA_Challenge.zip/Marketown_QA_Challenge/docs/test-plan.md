
# Plano de Testes — Marketown (SwagLabs Shopping)

## Escopo
Testes manuais funcionais das user stories US-01 (Login) e US-02 (Checkout).

## Estratégia
- Tipo: Testes funcionais manuais
- Nível: Testes de sistema/integração (foco em fluxo de compra)
- Técnica: Exploratory + Test cases documentados (step-by-step e BDD)
- Critérios de entrada: build disponível em ambiente de testes / staging
- Critério de saída: todos os casos críticos executados com sucesso ou com bugs reportados e triados

## Riscos
- Integração com gateway de pagamento fictício
- Dados inconsistentes de estoque
- Ambientes instáveis (deploys durante execução)

## Dados de teste
- Usuários: testuser@example.com / Test@123
- Produtos: Produto A (R$50), Produto B (R$30)
- Cartões simulados: 4111 1111 1111 1111

## Plano de execução
- Ciclo 1: validar fluxos críticos (login, adicionar ao carrinho, checkout feliz)
- Ciclo 2: validar fluxos alternativos e negativos (pagamento recusado, campos obrigatórios)
- Registrar evidências em cada execução (screenshots, logs)

## Critérios de severidade
- Blocker: pagamento processado com valor incorreto / vazamento de dados
- Critical: checkout impossibilitado para todos os usuários
- Major: funcionalidade com erros frequentes
- Minor: problemas de layout ou texto incorreto
