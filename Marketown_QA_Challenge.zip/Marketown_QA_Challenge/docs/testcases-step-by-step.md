
# Test Cases — Step‑by‑Step (mínimo 2)

## TC-01 — Login com credenciais válidas (Step-by-Step)
- Pré-condições: ambiente de teste disponível; usuário criado (testuser@example.com / Test@123)
- Passos:
  1. Acessar a URL da aplicação.
  2. Clicar em "Login".
  3. Inserir email: testuser@example.com.
  4. Inserir senha: Test@123.
  5. Clicar em "Entrar".
- Resultado esperado:
  - Usuário é redirecionado para a página de produtos.
  - Nome do usuário ou ícone de conta aparece no cabeçalho.
- Pós-condições: usuário logado.

## TC-02 — Finalizar compra com cartão válido (Step-by-Step)
- Pré-condições: usuário autenticado; carrinho com pelo menos 1 item.
- Passos:
  1. Acessar carrinho.
  2. Confirmar itens e quantidades.
  3. Clicar em "Finalizar compra".
  4. Inserir endereço de entrega válido.
  5. Inserir dados do cartão (4111 1111 1111 1111, validade, CVV).
  6. Confirmar pagamento.
- Resultado esperado:
  - Exibir confirmação de pedido com número.
  - E-mail de confirmação (simulado) enviado.
- Pós-condições: pedido criado no sistema (ambiente de teste).

