
# Test Cases — BDD (Given / When / Then) (mínimo 2)

## BDD-01 — Login com sucesso
**Cenário:** Login com credenciais válidas
Given que o usuário está na página de login  
And possui conta com email "testuser@example.com"  
When ele submete email e senha corretos  
Then ele deve ser redirecionado para a página de produtos  
And o ícone de conta deve estar visível

## BDD-02 — Checkout — pagamento recusado
**Cenário:** Pagamento recusado mantém itens no carrinho
Given que o usuário tem itens no carrinho  
And tenta pagar com cartão inválido  
When o sistema processa o pagamento e recebe recusa  
Then o sistema deve exibir mensagem de erro de pagamento  
And os itens devem permanecer no carrinho  
And o usuário pode tentar outro método de pagamento
