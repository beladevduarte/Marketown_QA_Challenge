
# Marketown — QA Challenge (SwagLabs Shopping)

Repositório entregue para o desafio **"O Dia a Dia de um QA: A Prática de Testes Manuais Funcionais"**.
Conteúdo preparado para subir no GitHub: documentação em Markdown (pronta para conversão em PDF), templates e casos de teste.

## Estrutura
```
/Marketown_QA_Challenge
├─ docs/
│  ├─ workflow-bug-lifecycle.md
│  ├─ userstories.md
│  ├─ mindmap-userstory1.md
│  ├─ test-plan.md
│  ├─ testcases-step-by-step.md
│  └─ testcases-bdd.md
├─ README.md
├─ LICENSE
└─ .gitignore
```

## O que está entregue
- Fluxo de trabalho e ciclo de vida de bugs (docs/workflow-bug-lifecycle.md)
- 2 User Stories (docs/userstories.md) com critérios de aceite
- Mind‑map textual (docs/mindmap-userstory1.md) para a User Story de Checkout
- Plano de testes (docs/test-plan.md)
- 2 casos de teste step‑by‑step (docs/testcases-step-by-step.md)
- 2 casos de teste BDD (docs/testcases-bdd.md)
- Instruções de como usar/convertir para PDF e subir no GitHub

## Como usar
1. Baixe o ZIP e extraia.
2. Faça commit e push para um repositório novo no GitHub.
3. Se quiser os PDFs prontos, eu posso gerar (opcional).  

---

Entrega preparada por ChatGPT — revise e personalize nomes, dados de teste e screenshots conforme necessário antes de publicar.
