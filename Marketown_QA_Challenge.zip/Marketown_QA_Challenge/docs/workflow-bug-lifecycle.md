
# Workflow & Ciclo de Vida de Bugs

## Objetivo
Definir como tarefas e bugs fluem entre os times (PO, Dev, QA) em um ambiente Scrum.

## Status sugeridos
- **Backlog**: item levantado, ainda não priorizado.
- **To Do / Ready**: pronto para ser puxado na sprint.
- **In Progress**: desenvolvimento em andamento.
- **In Review / Code Review**: PR criado, aguardando revisão.
- **In Test / QA**: pronto para testes manuais.
- **Blocked**: impedido por dependência.
- **Done / Closed**: funcionalidade validada e entregue.
- **Reopened**: bug reaberto após verificação.

## Ciclo de vida de um bug
1. **Encontrado** — QA detecta problema durante execução.
2. **Reportado** — Criado issue no Jira/GitHub com passos, evidências e severidade.
3. **Triagem (Triage)** — PO/Tech Lead avalia prioridade e classifica.
4. **Assigned** — Atribuído a um dev para correção.
5. **Fixed** — Dev marca como corrigido e abre PR.
6. **Verificado pelo QA** — QA testa a correção no ambiente.
7. **Closed** — Se aprovado, bug fechado.
8. **Reopen** — Se falhar, reabre com comentários e novas evidências.

## Campos essenciais no reporte de bug
- Título curto e objetivo
- Ambiente (dev/staging/prod)
- Versão / commit
- Passos para reproduzir (step-by-step)
- Resultado esperado / resultado atual
- Severidade / prioridade
- Evidências (screenshots / logs / vídeo)
- Labels (tipo, componente)
- Assign para responsável

## Boas práticas
- Reproduzir em ambiente limpo.
- Capturar logs e screenshots.
- Sempre anexar dados de teste e contas usadas.
- Verificar se não é um comportamento esperado ou configuração do ambiente antes de abrir bug.
