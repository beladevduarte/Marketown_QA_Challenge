
# Mind‑map (User Story: Finalizar compra)

Este arquivo descreve textualmente o mind‑map. Para versão visual, use XMind ou Miro e exporte PNG/PDF.

## Nó central: Checkout / Finalizar compra
- Pré-condições
  - Usuário autenticado
  - Itens no carrinho
  - Estoque disponível
- Fluxo principal (fluxo feliz)
  1. Abrir carrinho
  2. Revisar itens e quantidades
  3. Clicar em "Finalizar compra"
  4. Informar endereço de entrega
  5. Informar método de pagamento (cartão)
  6. Confirmar compra -> sistema processa -> exibe confirmação + número do pedido
- Fluxos alternativos / exceções
  - Pagamento recusado -> mostrar mensagem e permitir tentar outro método
  - Item sem estoque -> bloquear checkout e notificar remoção ou aguardar reposição
  - Endereço inválido -> validação e mensagem de erro
- Dependências
  - Serviço de pagamento (simulado)
  - Serviço de estoque
  - Serviço de cupons/descontos
- Dados de teste sugeridos
  - Conta: testuser@example.com / Senha: Test@123
  - Cartão: 4111 1111 1111 1111 - válido (simulação)
  - Cupom: TEST10 (desconto 10%)
